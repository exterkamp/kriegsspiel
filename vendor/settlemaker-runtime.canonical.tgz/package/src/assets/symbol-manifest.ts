// Frozen compatibility data for existing generator APIs.
// Current artwork is authored in scripts/art and built by scripts/build-runtime-art.mjs.

export type SymbolClass = 'fixed' | 'mark' | 'canopy' | 'pattern';
export type SymbolSheetZBand = 'ground' | 'parcel' | 'route' | 'structure' | 'canopy' | 'overlay';
export interface SymbolMeta {
  cls: SymbolClass;
  viewBox: [number, number, number, number];
  footprint: [number, number] | null;
  anchor: [number, number];
  rotation: 'invariant' | 'free' | 'locked' | 'snap-cardinal';
  zBand: SymbolSheetZBand;
  minScale: number;
  scaleTo?: string;
  tags: string[];
}

export const SYMBOL_MANIFEST: Record<string, SymbolMeta> = {
  "sm-well": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      3.2,
      3.2
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.35,
    "tags": [
      "civic",
      "water"
    ]
  },
  "sm-market-cross": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      6.5,
      6.5
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "snap-cardinal",
    "zBand": "structure",
    "minScale": 0.45,
    "tags": [
      "civic",
      "market"
    ]
  },
  "sm-mill-water": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      9,
      7.4
    ],
    "anchor": [
      34,
      32
    ],
    "rotation": "free",
    "zBand": "structure",
    "minScale": 0.5,
    "tags": [
      "industry"
    ]
  },
  "sm-mill-wind": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      7,
      7
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.5,
    "tags": [
      "industry"
    ]
  },
  "sm-mark-church": {
    "cls": "mark",
    "viewBox": [
      0,
      0,
      32,
      32
    ],
    "footprint": null,
    "anchor": [
      16,
      16
    ],
    "rotation": "locked",
    "zBand": "overlay",
    "minScale": 0.6,
    "scaleTo": "lot-short-axis*0.55",
    "tags": [
      "religion"
    ]
  },
  "sm-tree-deciduous": {
    "cls": "canopy",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      7.5,
      7.5
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "canopy",
    "minScale": 0.3,
    "tags": [
      "vegetation",
      "deciduous"
    ]
  },
  "sm-tree-deciduous-round": {
    "cls": "canopy",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      7.5,
      7.5
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "canopy",
    "minScale": 0.3,
    "tags": [
      "vegetation",
      "deciduous",
      "borderless"
    ]
  },
  "sm-amphitheatre": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      22,
      17
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.55,
    "tags": [
      "civic",
      "leisure"
    ]
  },
  "sm-bridge": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      8,
      3
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "free",
    "zBand": "route",
    "minScale": 0.4,
    "tags": [
      "infrastructure"
    ]
  },
  "sm-castle": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      24,
      20
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.55,
    "tags": [
      "civic",
      "military"
    ]
  },
  "sm-cathedral": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      14,
      20
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.5,
    "tags": [
      "religion",
      "civic"
    ]
  },
  "sm-docks": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      10,
      6
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "free",
    "zBand": "route",
    "minScale": 0.45,
    "tags": [
      "industry",
      "water"
    ]
  },
  "sm-dump": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      7,
      7
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.35,
    "tags": [
      "industry",
      "waste"
    ]
  },
  "sm-field": {
    "cls": "pattern",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": null,
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "parcel",
    "minScale": 0.3,
    "tags": [
      "agriculture"
    ]
  },
  "sm-field-fallow": {
    "cls": "pattern",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": null,
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "parcel",
    "minScale": 0.3,
    "tags": [
      "agriculture",
      "fallow"
    ]
  },
  "sm-field-harvested": {
    "cls": "pattern",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": null,
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "parcel",
    "minScale": 0.3,
    "tags": [
      "agriculture",
      "harvested"
    ]
  },
  "sm-house": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      6,
      6
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.4,
    "tags": [
      "residential"
    ]
  },
  "sm-house-tiled": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      6,
      6
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.4,
    "tags": [
      "residential"
    ]
  },
  "sm-house-large-tiled": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      8,
      8
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.45,
    "tags": [
      "residential"
    ]
  },
  "sm-hut-mud": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      4.5,
      4.5
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.35,
    "tags": [
      "residential",
      "vernacular"
    ]
  },
  "sm-hut-round": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      4.5,
      4.5
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.35,
    "tags": [
      "residential",
      "vernacular"
    ]
  },
  "sm-hut-straw": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      4.5,
      4.5
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.35,
    "tags": [
      "residential",
      "vernacular"
    ]
  },
  "sm-inn": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      7,
      6
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.45,
    "tags": [
      "civic",
      "hospitality"
    ]
  },
  "sm-longhouse": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      10,
      5
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.4,
    "tags": [
      "residential",
      "vernacular"
    ]
  },
  "sm-market": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      9,
      7
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.45,
    "tags": [
      "civic",
      "market"
    ]
  },
  "sm-mine": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      8,
      8
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.45,
    "tags": [
      "industry"
    ]
  },
  "sm-orchard": {
    "cls": "pattern",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": null,
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "parcel",
    "minScale": 0.35,
    "tags": [
      "agriculture",
      "vegetation"
    ]
  },
  "sm-park": {
    "cls": "pattern",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": null,
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "parcel",
    "minScale": 0.35,
    "tags": [
      "leisure",
      "vegetation"
    ]
  },
  "sm-racetrack": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      30,
      18
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "route",
    "minScale": 0.5,
    "tags": [
      "leisure"
    ]
  },
  "sm-road-cobbled": {
    "cls": "pattern",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": null,
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "route",
    "minScale": 0.3,
    "tags": [
      "infrastructure"
    ]
  },
  "sm-road-dirt": {
    "cls": "pattern",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": null,
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "route",
    "minScale": 0.3,
    "tags": [
      "infrastructure"
    ]
  },
  "sm-stables": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      8,
      6
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.4,
    "tags": [
      "agriculture",
      "industry"
    ]
  },
  "sm-temple": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      10,
      10
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.45,
    "tags": [
      "religion"
    ]
  },
  "sm-tower": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      6,
      6
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.4,
    "tags": [
      "military"
    ]
  },
  "sm-town-hall": {
    "cls": "fixed",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      9,
      7
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "structure",
    "minScale": 0.45,
    "tags": [
      "civic"
    ]
  },
  "sm-town-square": {
    "cls": "pattern",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": null,
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "parcel",
    "minScale": 0.35,
    "tags": [
      "civic"
    ]
  },
  "sm-tree-conifer": {
    "cls": "canopy",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": [
      6,
      6
    ],
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "canopy",
    "minScale": 0.3,
    "tags": [
      "vegetation",
      "conifer"
    ]
  },
  "sm-vineyard": {
    "cls": "pattern",
    "viewBox": [
      0,
      0,
      64,
      64
    ],
    "footprint": null,
    "anchor": [
      32,
      32
    ],
    "rotation": "invariant",
    "zBand": "parcel",
    "minScale": 0.35,
    "tags": [
      "agriculture"
    ]
  }
};
