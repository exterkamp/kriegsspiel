import { biomeThemeFor } from '../appearance/biomes.js';
import type { Palette } from '../types/interfaces.js';

export const PALETTE_DEFAULT: Palette  = { paper: 0xccc5b8, light: 0x99948a, medium: 0x67635c, dark: 0x1a1917, water: 0x8fbbc9, green: 0xa5a393 };
export const PALETTE_BLUEPRINT: Palette = { paper: 0x455b8d, light: 0x7383aa, medium: 0xa1abc6, dark: 0xfcfbff, water: 0x354b7d, green: 0x5a7090 };
export const PALETTE_BW: Palette        = { paper: 0xffffff, light: 0xcccccc, medium: 0x888888, dark: 0x000000, water: 0xdddddd, green: 0xbbbbbb };
export const PALETTE_INK: Palette       = { paper: 0xcccac2, light: 0x9a979b, medium: 0x6c6974, dark: 0x130f26, water: 0x7a8896, green: 0x9a9790 };
export const PALETTE_NIGHT: Palette     = { paper: 0x000000, light: 0x402306, medium: 0x674b14, dark: 0x99913d, water: 0x0a1628, green: 0x2a3a18 };
export const PALETTE_ANCIENT: Palette   = { paper: 0xccc5a3, light: 0xa69974, medium: 0x806f4d, dark: 0x342414, water: 0x8ba89b, green: 0xa59a70 };
export const PALETTE_COLOUR: Palette    = { paper: 0xfff2c8, light: 0xd6a36e, medium: 0x869a81, dark: 0x4c5950, water: 0x7cb5c9, green: 0xb0c890 };
export const PALETTE_SIMPLE: Palette    = { paper: 0xffffff, light: 0x000000, medium: 0x000000, dark: 0x000000, water: 0xcccccc, green: 0xcccccc };

/** MFCG-style warm parchment. Values sampled from watabou MFCG 0.11.5 renders. */
export const PALETTE_PARCHMENT: Palette = { paper: 0xfff2c8, light: 0xd5ad6e, medium: 0xa08a5a, dark: 0x4a3f2a, water: 0x85bcb2, green: 0x8fa26a };

const NAMED_PALETTES = {
  default: PALETTE_PARCHMENT,
  classic: PALETTE_DEFAULT,
  parchment: PALETTE_PARCHMENT,
  blueprint: PALETTE_BLUEPRINT,
  bw: PALETTE_BW,
  ink: PALETTE_INK,
  night: PALETTE_NIGHT,
  ancient: PALETTE_ANCIENT,
  colour: PALETTE_COLOUR,
  simple: PALETTE_SIMPLE,
} satisfies Record<string, Palette>;

export const PALETTES: Record<string, Palette> = NAMED_PALETTES;
export type ThemeName = keyof typeof NAMED_PALETTES;

export function paletteForTheme(name: ThemeName): Palette {
  if (!Object.hasOwn(PALETTES, name)) throw new RangeError(`Unknown settlement theme "${String(name)}".`);
  return PALETTES[name];
}

/** Natural regional colours shared by both engines. Explicit palettes override these. */
export function paletteForBiome(biome?: string): Palette {
  const theme = biomeThemeFor(biome);
  const color = (hex: string) => parseInt(hex.slice(1), 16);
  return {
    paper: color(theme.ground), light: 0xe8dcc0, medium: 0x8a6f4a, dark: 0x33262e,
    water: color(theme.water), green: color(String(theme.tokens?.['--sm-common'] ?? '#a8bf6d')),
  };
}
